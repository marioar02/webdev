
    //acceder a menu principal

    //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
    var seccionActual = "inicio";
    //importo las funciones del servidor
    var app = rpc("localhost", "migestionpaciente")
    var login=app.procedure("login")
    var datosMedico=app.procedure("datosMedico")
    var listadoVariables=app.procedure("listadoVariables")
    var listadoMuestras=app.procedure("listadoMuestras")
    var eliminar=app.procedure("eliminar")
    var anyadir=app.procedure("anyadir")
    //variables globales
    var p_muestras;
    var patients;
    var muestra_a_compartir;
    var conexion;
    var lista_muestras;
    var v_select;
    var variable_nombre_a_enviar;
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    function cambiarSeccion(seccion){
        document.getElementById(seccionActual).classList.remove("activa");
        document.getElementById(seccion).classList.add("activa");
        seccionActual=seccion;
        }
  
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//Login
function entrar(){
    //codigo de acceso y se comprueba si es o no
    cod=document.getElementById("codac").value
    //asincronía
    console.log(cod)
    login(cod,function(paciente){
        if (paciente==null){
            alert("paciente no encontrado")
        }
        else{
            //si se encuentra se crea el socket, se localizan las variables y
            //se abre el menu del paciente
            obtenerdatospac(paciente);
            crearNewWS(paciente);
            listadoVariables(function(v){
                variables=v;
            });
        }
        
        });

}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
function crearNewWS(paciente){
        // Connection opened
    conexion = new WebSocket('ws://localhost:4444', "pacientes");
    conexion.addEventListener('open', function (event) {
    console.log("Cliente conectado!!!");
    //para identificar la conexion con el id del paciente y un rol que en este caso es paciente
    conexion.send(JSON.stringify({ operacion: "identificar", rol: "paciente", id:paciente.id}));

    });
    //MEnsajes
    conexion.addEventListener('message',  (event) => {
        //creo un addeventlistener para escuchar los mensajes
        const msg = JSON.parse(event.data);
        //el mensaje que llegue
        switch (msg.operacion) {
            //notificar, es enviar un mensaje
            case "notificar":
            //texto es el mensaje del otro paciente
            const texto = msg.mensaje;
            console.log(texto);
            //se le añade a la lista de mensajes el mensaje
            lista_mensajes= document.getElementById("mensajes");   
            lista_mensajes.innerHTML+="<li>"+texto+'</li>';
            //se recarga la página
            obtenerdatospac(p_muestras)
                break;
        case "login":
            //recoger los datos de los demas pacientes para la mensajeria
            console.log("Mensaje del servidor:", event.data);
            patients = JSON.parse(event.data);
            patients=patients.datos;
            //patients será una lista de los pacientes
            default:
                break;
        }
    });
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
function obtenerdatospac(p){
//menu principal
//se recoge en p_muestras el paciente en el que esta logeado
    p_muestras=p;
    datosMedico(p.medico,function(medico){
        if (medico==null){
            alert("no tienes ningun médico asignado")
        }
        else{
            var mensaje_bienvenida=document.getElementById("bienvenida");
            mensaje_bienvenida.innerHTML= "Bienvenido: "+p.nombre;
            var mens_med=document.getElementById("nombre_medico");
            mens_med.innerHTML=" Su médico es"+medico.nombre;
            
        }});
        //mostrar observaciones
        obs=document.getElementById("obs");
        obs.innerHTML="Observaciones: "+p.observaciones;
        listadoMuestras(p.id,function(l_m){lista_muestras=l_m;
            mostrarVariables();});
        
        cambiarSeccion("menu-principal")
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function comunidades_select(){
        com=document.getElementById("ranking").value;
        comunidades=["Andalucía","Aragón","Asturias",
        "Islas Baleares","Canarias","Cantabria","Castilla-La Mancha",
        "Castilla y León","Cataluña"
        ,"Comunidad de Madrid","Comunidad Foral de Navarra",
        "Comunidad Valenciana","Extremadura","Galicia",
        "País Vasco","Principado de Asturias","Región de Murcia",
        "La Rioja"]
        
        val="Nacional"
        for (let i = 0; i < comunidades.length; i++) {
            if (comunidades[i]==com){
                val=i+1;

            }
        }
        return val
        console.log(val)
    }
    function get_datos_server(){
        datos_peso=[];
        datos_andados=[];
        datos_recorridos=[]
        id_com=comunidades_select();
        if (id_com=="Nacional"){
            rest.get("https://undefined.ua.es/telemedicina/api/datos",function(estado,resp){
                if (estado==200){
                    for (var i in resp){
                        data_m=resp[i].datos
                        for (var j in data_m){
                            try {
                            if (data_m[j].variable=="peso"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined'|| typeof data_m[j].valor === 'string'  || typeof data_m[j].paciente === 'undefined'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_peso.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }

                            }
                            if (data_m[j].variable=="metros_andados"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined' || typeof data_m[j].paciente === 'undefined' || typeof data_m[j].valor === 'string'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_andados.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }
                                
                            }
                            
                            if (data_m[j].variable=="metros_recorridos" ||data_m[j].variable=="metros_corridos"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined' || typeof data_m[j].paciente === 'undefined' || typeof data_m[j].valor === 'string'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_recorridos.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }

                            }
                            } 
                            catch (error) {
                            console.log(error);
                          }
                        }

                    };
                    datos_peso.sort(function(a, b){return   b['valor']-a['valor']});
                    datos_andados.sort(function(a, b){return   b['valor']-a['valor']});
                    datos_recorridos.sort(function(a, b){return   b['valor']-a['valor']});
                    console.log(datos_andados)
                    r_peso=document.getElementById("Ranking_peso");
                    r_and=document.getElementById("Ranking_recorridos");
                    r_corr=document.getElementById("Ranking_andados");
                    r_peso.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Peso (kg)</th></tr>";
                    r_and.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Metros andados</th></tr>";
                    r_corr.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Metros corridos</th></tr>";

                    for (var i = 0; i < 20; i++){
                        try{
                            r_peso.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>" + datos_peso[i].nombre  +"</td>"+ "<td>" + datos_peso[i].valor+"</td>"+'</tr>';
                        }catch{};
                        try{
                            r_and.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>"+ datos_andados[i].nombre  +"</td>"+ "<td>"+  datos_andados[i].valor+"</td>"+'</tr>';
                        }catch{};
                        try{
                            r_corr.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>"+ datos_recorridos[i].nombre  +"</td>"+ "<td>"+  datos_recorridos[i].valor+"</td>"+'</tr>';
                        }catch{};

                    }
                    }
                    
                else{
                    alert("ha ido mal"+resp);
                }
            });
        }
        else{
            rest.get("https://undefined.ua.es/telemedicina/api/datos",function(estado,resp){
                if (estado==200){
                    for (var i in resp){
                        data_m=resp[i].datos
                        if (resp[i].id_area==id_com){
                            for (var j in data_m){
                            try {
                            if (data_m[j].variable=="peso"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined' || typeof data_m[j].paciente === 'undefined' || typeof data_m[j].valor === 'string'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_peso.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }

                            }
                            if (data_m[j].variable=="metros_andados"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined' || typeof data_m[j].paciente === 'undefined' || typeof data_m[j].valor === 'string'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_andados.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }
                                
                            }
                            
                            if (data_m[j].variable=="metros_recorridos" ||data_m[j].variable=="metros_corridos"){
                                if (data_m[j].paciente==null || data_m[j].valor==null || typeof data_m[j].valor === 'undefined' || typeof data_m[j].paciente === 'undefined' || typeof data_m[j].valor === 'string'||  data_m[j].paciente == ''||  data_m[j].valor == ''){
                                    console.log("mal")
                                }
                                else{
                                    datos_recorridos.push({"nombre":data_m[j].paciente,"valor":data_m[j].valor});
                                }

                            }
                            } 
                            catch (error) {
                            console.log(error);
                          }
                        }

                        }
                        
                    };
                    datos_peso.sort(function(a, b){return   b['valor']-a['valor']});
                    datos_andados.sort(function(a, b){return   b['valor']-a['valor']});
                    datos_recorridos.sort(function(a, b){return   b['valor']-a['valor']});
                    console.log(datos_recorridos)
                    console.log(datos_andados)
                    r_peso=document.getElementById("Ranking_peso");
                    r_and=document.getElementById("Ranking_recorridos");
                    r_corr=document.getElementById("Ranking_andados");
                    r_peso.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Peso (kg)</th></tr>";
                    r_and.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Metros andados</th></tr>";
                    r_corr.innerHTML="<tr><th>Posición</th><th>Nombre</th>  <th>Metros corridos</th></tr>";

                    for (var i = 0; i < 20; i++){
                        try{
                            r_peso.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>" + datos_peso[i].nombre  +"</td>"+ "<td>" + datos_peso[i].valor+"</td>"+'</tr>';
                        }catch{};
                        try{
                            r_and.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>"+ datos_andados[i].nombre  +"</td>"+ "<td>"+  datos_andados[i].valor+"</td>"+'</tr>';
                        }catch{};
                        try{
                            r_corr.innerHTML+="<tr>"+"<td>" + parseInt(i+1)  +"</td>"+"<td>"+ datos_recorridos[i].nombre  +"</td>"+ "<td>"+  datos_recorridos[i].valor+"</td>"+'</tr>';
                        }catch{};

                    }
                    
                }
                else{
                    alert("ha ido mal"+resp);
                }
            });
        }
    }

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------


    function fsync(){
        listadoVariables(function(v){
            variables=v;
        
        console.log("hoaaaaaaaaaaaaaaaa")
        var req_muestras=[]
        for (var i of lista_muestras){
            if (i.variable=="1" ){
                req_muestras.push({"paciente":p_muestras.nombre,"fecha":i.fecha,"valor":i.valor,"variable":"peso"})
                
            }
            else if(i.variable=="5"){
                req_muestras.push({"paciente":p_muestras.nombre,"fecha":i.fecha,"valor":i.valor,"variable":"metros_andados"})
            }
            else if(i.variable=="6"){
                req_muestras.push({"paciente":p_muestras.nombre,"fecha":i.fecha,"valor":i.valor,"variable":"metros_recorridos"})
            }
            
        }
        var today = new Date();
 
        // `getDate()` devuelve el día del mes (del 1 al 31)
        var day = today.getDate();
        
        // `getMonth()` devuelve el mes (de 0 a 11)
        var month = today.getMonth() + 1;
        
        // `getFullYear()` devuelve el año completo
        var year = today.getFullYear();
        
        // muestra la fecha de hoy en formato `MM/DD/YYYY`
        f=(year+"-"+month+"-"+day)
        body_req={"id_area":1,"fecha":f,"datos":req_muestras}
        console.log(body_req)
        rest.post("https://undefined.ua.es/telemedicina/api/datos",body_req,function(estado,resp){
            if (estado==201){
                alert("esta todo enviado correctamente")            
            }
            else{
                alert("ha ido mal"+resp);
            }
        });
    });
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //mostrar variables
    function mostrarVariables(){
        //elimina el poder visualizar el formulario para compartir si se podía antes
        document.getElementById("formcomp").classList.remove("activa");
        //se identifica la variable seleccionada
        v_select=document.getElementById("variables").value;
        //lista_variables_muestras: se van a seleccionar las muestras que tengan la variable seleccionada
        lista_variables_muestras=[];
        //se relaciona el id de las variables con el nombre y se coge el id de la variable que tenga el nombre de v_select
        for (var j of variables){
            if (v_select==j.nombre){
                v_select=j.id;
            }
        }
        //bucle: comprueba el idVariable de cada muestra con la variable objetivo. eso se lo agrega a lista_variables_muestras si coinciden
        for (var i of lista_muestras){
            if (i.variable==v_select){
                lista_variables_muestras.push(i);
                lista_variables_muestras.sort((a, b) => a.fecha - b.fecha);
                console.log(lista_variables_muestras)
                }                               
            }
        //se agregan al <ul> las muestras
        var muestras= document.getElementById("muestras");   
        muestras.innerHTML = "";
        for (var i of lista_variables_muestras) {
            muestras.innerHTML+="<li>"+"id" + i.id + " fecha" + i.fecha + " valor" + i.valor+'</li>';
            muestras.innerHTML+='<button onclick="quitar('+i.id+')">eliminar</button>';
            muestras.innerHTML+='<button onclick="verFormCompartir('+i.id+')">compartir</button>';
                
        }
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //se muestra el formulario de añadir y se configura para que por defecto la fecha sea la de hoy
    function formany(){
        var fecha = new Date(); //Fecha actual
        var mes = fecha.getMonth()+1; //obteniendo mes
        var dia = fecha.getDate(); //obteniendo dia
        var ano = fecha.getFullYear(); //obteniendo año
            if(dia<10){
                dia='0'+dia; //agrega cero si el menor de 10
            }
              
            if(mes<10){
              mes='0'+mes //agrega cero si el menor de 10
              document.getElementById('fechaEd').value=ano+"-"+mes+"-"+dia;
          }
        document.getElementById("anyadirm").classList.add("activa") ;
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//
    function anyadirm(){
        vari=document.getElementById('varEd').value;
        fecha=document.getElementById('fechaEd').value;
        fecha=new Date(fecha);
        valor=document.getElementById('valorEd').value;
        if (vari==""){
            alert("introduce la variable")
        }
        if (fecha==""){
            alert("introduce la fecha")
        }
        if (valor==""){
            alert("introduce la valor")
        }
        //funcion de añadir
        anyadir(p_muestras.id,vari,fecha,valor,function(correct){
            if (correct!=true){
                alert("prueba a hacerlo mejor")
            }
            else{
                mostrarVariables();
                obtenerdatospac(p_muestras);
                document.getElementById("anyadirm").classList.remove("activa");
                
            }
             
        });

            
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//se muestra  el formulario de compartir
function verFormCompartir(id_muestra_seleccionada){
    //identificar la muestra en la lista de muestras mediante el id
    for (var i of lista_muestras){
        if (i.id==id_muestra_seleccionada){
            muestra_a_compartir=i;
        }
    }
    //identificar variable id, variable nombre
    for (var j of variables){
        if (muestra_a_compartir.variable==j.id){
           variable_nombre_a_enviar=j.nombre;
        }
    }
    document.getElementById("formcomp").classList.add("activa");
};
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
function comprobarValor(){
    //valor del select
    valor_desti=document.getElementById("select_desti").value;
    //recogemos la lista a la que agregamos los pacientes que podemos enviar mensaje
    todos_pacientes=document.getElementById("all_pacientes");
    //si es amigo, se le agregará
    if (valor_desti=="amigo"){
        todos_pacientes.innerHTML="";
        for (var i of patients){
            //si el id del paciente, es igual que el paciente que se ha logeado, no lo vamos a agregar a la lista
            if (i.id!=p_muestras.id){
                if(p_muestras.medico==i.medico){
                    todos_pacientes.innerHTML+="<li>"+"id: " + i.id + " Nombre: " + i.nombre +'</li>';
                    todos_pacientes.innerHTML+='<input type="checkbox" id="patient'+i.id+'">';
                }

            }
        }   
    }
    else{
        todos_pacientes.innerHTML="";
    }
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//enviar 

function enviar(){
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    if (document.getElementById("select_desti").value=="amigo") {
        //si es amigo, se le enviará a los id_a_enviar de la siguiente forma:
        id_a_enviar=[]
        for (var i of patients){
            //se recorrerá la lista de los pacientes y se comprobará el id
            if (i.id!=p_muestras.id){
                //si esta checked, se agrega a la lista de id_a_enviar
                if(p_muestras.medico==i.medico){
                    if(check=document.getElementById("patient"+i.id).checked){
                        id_a_enviar.push(i.id);
                    };
            }
            }
        }
    // se envian el mensaje, el id que envia el mensaje(id_sent) y la lista de ids a enviar(ids)y la operacion
    conexion.send(JSON.stringify({ id_sent:p_muestras.id ,operacion: "enviar_amigos", mensaje:"El paciente: "+p_muestras.nombre +" ha compartido :"+variable_nombre_a_enviar+" el dia: "+muestra_a_compartir.fecha+"con valor: "+muestra_a_compartir.valor,
    ids:id_a_enviar }));
    console.log("se ha enviado")
    }
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //lo mismo pero sin distinción del checked
    if (document.getElementById("select_desti").value=="todos") {
        id_a_enviar=[]
        for (var i of patients){
            if (i.id!=p_muestras.id){
                    id_a_enviar.push(i.id);
            }
        }
        conexion.send(JSON.stringify({ id_sent: p_muestras.id ,operacion: "todos", mensaje:"El paciente: "+p_muestras.nombre +" ha compartido :"+variable_nombre_a_enviar+" el dia: "+muestra_a_compartir.fecha+"con valor: "+muestra_a_compartir.valor,
        ids:id_a_enviar }));
        console.log("se ha enviado")
    }
    //-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    //si está checked se envia lo mismo pero con operaciones medico y con el ids es el id del medico en una lista
    if (document.getElementById("medico_check").checked) {
        conexion.send(JSON.stringify({ id_sent:p_muestras.id ,operacion: "medico", mensaje:"El paciente: "+p_muestras.nombre +" ha compartido :"+variable_nombre_a_enviar+" el dia: "+muestra_a_compartir.fecha+"con valor: "+muestra_a_compartir.valor,
        ids:[p_muestras.medico] }));
        console.log("se ha enviado")
    }

}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//elimina la muestra con id: id
    function quitar(id){
        eliminar(id,function(){
            obtenerdatospac(p_muestras);
            mostrarVariables();
        });

    }            
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function datosUsuario(){
        var usuario = document.getElementById("usuario").value;
        //...
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function salir(){
        cambiarSeccion("inicio");
        document.getElementById("anyadirm").classList.remove("activa");
        document.getElementById("formcomp").classList.remove("activa");
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function volver(){
        cambiarSeccion("menu-principal");
    }


