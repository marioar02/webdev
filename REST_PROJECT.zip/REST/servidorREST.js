var express = require("express");
var app = express();
var jwt = require('jwt-simple');
var clave = 'miSecreto';
app.use("/medico", express.static("medico"));
app.use("/paciente", express.static("paciente"));
app.use(express.json()); // en el req.body tengamos el body JSON
var datos=require("./datos.js")
var mysql = require("mysql");
var database ={
    host:"localhost",
    user:"root",
    password:"",
    database :"pr_telemed",
    port:3306
};
//---------------------------conexión base de datos----------------------------------------------
var conexion = mysql.createConnection(database);
conexion.connect(function(err){
    if(err){
        console.log("Se ha producido un error al conectar a la base de datos",err);
        process.exit();
    }else{
        console.log("Base de datos conectada correctamente!!!");
    }
});

//---------------------------conexión base de datos-----------------------------------------------
//-------------------------------------METODOS-------------------------------------------------------------------------//


//SEGUNDA--login
app.post("/api/medico/login", function (req, res) {
    var usuario={
    login: req.body.login,
    password:req.body.password,
    }
    //usuario son los datos de inicio
    verify=false
    var sql = "SELECT id FROM medicos WHERE login = "+JSON.stringify(usuario.login)+" AND password = "+JSON.stringify(usuario.password)+"";
    conexion.query(sql,function(err,idmedico){
            if(err){
                res.status(500).json("Error al realizar la consulta");
            }
            else{
                if(idmedico.length>=1){
                    var contenido = { // contenido del token (se puede incluir la información que necesitemos)
                        usuario: idmedico[0],
                        expira: Date.now() + 60 * 60 * 1000 // expira dentro de 1 hora (en ms)
                    };
                    var token = jwt.encode(contenido, clave);
                    object_Tok={"id":idmedico[0],"token":token}
                    res.status(200).json(object_Tok);

                }
                else{
                    res.status(404).json("Error al realizar la consulta");
                }

            }
    })


});
//____________________________________________________________________________________________________________________________________________________________

app.use("/api", function (req, res, next) {
    var token = req.query.token; // obtengo el token de una query de la URL: http://MI_SERVIDOR/MI_RUTA?token=XXXXXXXX
    if (!token) { // no se ha pasado un token
        res.status(301).json("No se ha encontrado token");
        return;
    }

    // Decodificar el token
    try { // capturamos el error por si el token no es correcto
        var contenidoToken = jwt.decode(token, clave); // decodificamos el token para obtener su contenido con la misma clave que se codificó
    } catch (error) {
        res.status(301).json("El token es incorrecto");
        return;
    }
    console.log("El contenido del token es:", contenidoToken);

    // Validar el token
    if (!contenidoToken || !contenidoToken.expira || !contenidoToken.usuario) { // validamos el formato del token
        res.status(301).json("El formato del token no es adecuado")
        return;
    }

    // Comprobar la fecha de expiración
    if (contenidoToken.expira < Date.now()) {
        res.status(301).json("El token ha expirado");
        return
    }
    // Todo ha ido bien. con next hago que express continue con el procesado
    next();
});
//PRIMERA

//envia las variables
app.get("/api/variable", function (req, res) {
    var sql = "SELECT * FROM variables";
    conexion.query(sql,function(err,variables){
        if(err){
            console.log("Error al realizar la select",err);
            res.status(500).json("Error al realizar la consulta");
        }else{
            console.log("variables:",variables);
            res.status(200).json(variables);        }
   });

});
//
//____________________________________________________________________________________________________________________________________________________________
//TERCERA--devuelve valores del paciente
app.get("/api/paciente/:id", function (req, res) {
    var idpac = req.params.id;
    var sql = "SELECT id,nombre,fecha_nacimiento,genero,medico,observaciones FROM pacientes WHERE id = "+idpac+"";

    conexion.query(sql,function(err,datospac){
        if(err){
            res.status(500).json("Error al realizar la consulta");
        }
        else{
            if (datospac.length>=1){
                datos_paciente=Object.values(datospac[0]);
                res.status(200).json(datos_paciente);

            }
            else{
                res.status(404).json("Error al realizar la consulta");
            }

}});
    

});
//
//CUARTA-datos medico
app.get("/api/medico/:id", function (req, res) {
    var idpac = req.params.id;
    var sql = "SELECT id,nombre,login FROM medicos WHERE id = "+idpac+"";

    conexion.query(sql,function(err,datosmed){
        if(err){
            res.status(500).json("Error al realizar la consulta");
        }
        else{
            if (datosmed.length>=1){
                res.status(200).json(datosmed[0])
            }
            else{
                res.status(404).json("Error al realizar la consulta");
            }
            
;}

});});
//
//QUINTA--envía los pacientes
app.get("/api/medico/:id/pacientes", function (req, res) {
    var idmed = req.params.id

    var sql = "SELECT * FROM pacientes WHERE Medico = "+idmed+"";

    conexion.query(sql,function(err,pacientesmed){
        if(err){
            res.status(500).json("Error al realizar la consulta");
        }
        else{
            if(pacientesmed.length >=1){
                res.status(200).json(pacientesmed);
            }
            else{
                res.status(301).json("Usuario Incorrecto");
            }

        }
    })
});
//
//SEXTA--añadir
app.post("/api/medico/:id/pacientes", function (req, res) {
    //se recogen los parametros de entrada que se guardan en req.body
    var npac={
        id: req.body.id,
        nombre:req.body.nombre,
        fecha_nacimiento:req.body.fecha_nacimiento,
        genero:req.body.genero,
        medico:req.body.medico,
        codigo_acceso:req.body.codigo_acceso,
        observaciones:req.body.observaciones,
        };
    //se comprueba si existe
    var sql="INSERT INTO pacientes (id,nombre,fecha_nacimiento,genero,medico,cod_acceso,observaciones ) VALUES ("+npac.id+","+JSON.stringify(npac.nombre)+","+JSON.stringify(npac.fecha_nacimiento)+","+JSON.stringify(npac.genero)+","+npac.medico+","+JSON.stringify(npac.codigo_acceso)+","+JSON.stringify(npac.observaciones)+")"

    conexion.query(sql,function(err,respuesta){
        if(err){
            res.status(500)
        }
        else{
            res.status(201).json(respuesta.insertId)
        }
    });
});

//SEPTIMA--editar

app.put("/api/paciente/:id", function (req, res) {
    var id=req.params.id;
    var datos=req.body;
    console.log(req.body.fecha_nacimiento)
    
    var sql = "UPDATE pacientes SET  nombre = '"
    +req.body.nombre + "', fecha_nacimiento = '"
    +req.body.fecha_nacimiento + "', genero = '"
    +req.body.genero + "', medico = '"
    +req.body.medico + "', cod_acceso = '"
    +req.body.codigo_acceso + "', observaciones = '"
    +req.body.observaciones+"' WHERE id= "+id;
    console.log(sql)

    conexion.query(sql,function(err,paced){
        if(err){
            res.status(500).json("Error al realizar la actualización");
        }
        else{
            console.log(paced);
            res.status(201).json(paced);
        }
    })


});
//----------------------------------------------------------------------------------------------------------------------------------------------------------------//

//NOVENA--enviar muestras del paciente con id :id
app.get("/api/paciente/:id/muestras", function (req, res) {
    var idpaciente=req.params.id;

    var sql = "SELECT * FROM muestras WHERE paciente ="+idpaciente;
    conexion.query(sql,function(err,muestraspac){
        if(err){
            res.status(500).json("Error al realizar la consulta");
        }
        else{
            if (muestraspac.length>=1){
                datos_paciente=Object.values(muestraspac);
                res.status(200).json(datos_paciente);

            }
            else{
                res.status(404).json("Error al realizar la consulta");
            }

}});
});
//--------------------------------------------------------------------------fFunción de examen--------------------------------------------------------------------------------------//

app.put("/api/hospital/cambiar_director", function (req, res) {

    var sql = "UPDATE hospitales SET  director = "+6+" WHERE id= "+1;

    conexion.query(sql,function(err,director){
        if(err){
            res.status(500).json("Error al realizar la actualización");
        }
        else{
            res.status(201).json(director);
        }
    })


});
//----------------------------------------------------------------------------------------------------------------------------------------------------------------//
//duplicar
function definir_id(){
    id_rand=Math.floor(Math.random() * (1000 - 0)) + 0;
    id_exist=false;
    for (var j of datos.pacientes){
        if (j.id==id_rand){
            definir_id();
            id_exist=true;
            //si existe vuelve a lanzar la función
        }
    }
    if (id_exist==false){
        return(id_rand);
    }
    
}
//----------------------------------------------------------------------------------------------------------------------------------------------------------------//
app.post("/api/paciente/:id/duplicar",function(req,res){
    id_a_duplicar=req.params.id;
    id_rand=definir_id();
        for (var i of datos.pacientes){
            if (i.id==id_a_duplicar){
                pac={id:id_rand,nombre:i.nombre,fecha_nacimiento:i.fecha_nacimiento,genero:i.genero,medico:i.medico,codigo_acceso:i.codigo_acceso,observaciones:i.observaciones}
                datos.pacientes.push(pac);
            }
    }
    res.status(201).json(true);
})

app.listen(8080);