var rpc=require("./rpc.js");
rpc.debug = true;
var datos=require("./datos.js")
medicos=datos.medicos;
pacientes=datos.pacientes;
variables=datos.variables;
muestras=datos.muestras;

var mysql = require("mysql");
var database ={
    host:"localhost",
    user:"root",
    password:"",
    database :"pr_telemed",
    port:3306
};
//---------------------------conexión base de datos----------------------------------------------
var conexion = mysql.createConnection(database);
conexion.connect(function(err){
    if(err){
        console.log("Se ha producido un error al conectar a la base de datos",err);
        process.exit();
    }else{
        console.log("Base de datos conectada correctamente!!!");
    }
});

//---------------------------conexión base de datos-----------------------------------------------

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
function login(codigoAcceso, callback){
    conexion.query("SELECT * FROM pacientes WHERE cod_acceso = \""+codigoAcceso+"\"", function(error, paciente){
        if (error){
            callback(null);
        }
        else{
            if (paciente.length == 0){
                callback(null);
            }
            else{
                callback(paciente[0]);
            }
        }
        console.log(paciente[0]);
    });
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//devuelve listado de variables

function listadoVariables(callback){
    conexion.query("SELECT * FROM variables", function (error, variables){
        if(error) {
            callback(null);
        }
        else{
            if (variables.length==0){
                callback(null);
            }
            else{
                callback(variables);
            }
        }
    });
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//datos del medico (nombre e id)
function datosMedico(idMedico, callback){
    conexion.query("SELECT id, nombre FROM medicos WHERE id = \""+idMedico+"\"", function(error,datosM){
        if (error){
            callback(null);
        }
        else{
            if (datosM.length==0){
                callback(null);
            }
            else{
                callback(datosM[0]);
            }
        }
    });
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//devuelve la lista de muestras del paciente con idPaciente o null si no hay ninguna muestra con ese paciente
function listadoMuestras(idPaciente,callback){
    conexion.query("SELECT * FROM muestras WHERE paciente="+idPaciente, function (error, muestras){
        console.log(muestras);
        if(error) {
            callback(null);
        }
        else{
            if (muestras.length==0){
                
                callback(null);
            }
            else{
                callback(muestras);
            }
        }
    });}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//eliminar hace un splice
//SEXTA
function eliminar(id,callback){
    conexion.query("DELETE  FROM muestras WHERE id="+id, function (error, muestras){
        console.log(muestras)
        if (error){
            callback(false);
        }
        else{
                callback(true);
        }
});
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//añade una muestra
function anyadir(idPaciente,idVariable,fecha,valor,callback){ // hay un parámetro adicional (siempre el último) que es la función callback. SIEMPRE hay que llamar callback
    conexion.query("INSERT INTO muestras (paciente, variable, fecha, valor) VALUES ("+idPaciente+"," +idVariable+",'"+ fecha+"',"+ valor+")",function(error, nuevaM){
        if (error){
            callback(true);
        }
        else{
            if(nuevaM.length==0){
                callback(false);
            }
            else{
                callback(true);
            }
        }
    }); 
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
var servidor=rpc.server();
var app= servidor.createApp("migestionpaciente")
app.registerAsync(login);
app.registerAsync(listadoVariables);
app.registerAsync(datosMedico);
app.registerAsync(listadoMuestras);
app.registerAsync(eliminar);
app.registerAsync(anyadir);