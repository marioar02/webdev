//acceder a menu principal
    //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------//
    var seccionActual = "inicio";
    var id_select;//inicializo variable del medico que iniciará sesión
    var token;
    function cambiarSeccion(seccion){//función cambiar sección
        document.getElementById(seccionActual).classList.remove("activa");
        document.getElementById(seccion).classList.add("activa");
        seccionActual=seccion;
        }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//login

    function entrar(){
        var entradas = {
            login: document.getElementById("login").value,
            password: document.getElementById("password").value
        };
        if (entradas.login=="" || entradas.password==""){
            alert('Credenciales incorrectas')
        }
        else{
            rest.post("/api/medico/login", entradas, function (estado, respuesta) {
                token=respuesta.token;
                //si todo bien:
                if (estado == 200) {
                //resto de variables y comprobación. Si todo es correcto...
                    id_select=respuesta.id.id;
                    //inicia sockets
                    crearNewWS();
                    //crea el menu principal
                    obtenerdatosmed(id_select);
                cambiarSeccion("menu-principal");
                    
                } else {
                    alert("Credenciales incorrectas");
                }
        
            })

        }
        //envio los valores de entrada al server y comprueba si son correctos ahí
        
    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

function crearNewWS(){

        // Connection opened
        conexion = new WebSocket('ws://localhost:4444', "pacientes");
        conexion.addEventListener('open', function (event) {
            console.log("Cliente conectado!!!");
            //identificar la conexion en el server
            conexion.send(JSON.stringify({ operacion: "identificar", rol: "medico", id:id_select}));
    
        });
    
    
        //Mensajes
        conexion.addEventListener('message',  (event) => {
            const msg = JSON.parse(event.data);
                console.log(msg)
    
            switch (msg.operacion) {
                //si operacion==notificar, muestra alerta en pantalla con mensaje de paciente
                case "notificar":
                    const texto = msg.mensaje;
                    console.log(texto);
                    alert(texto);
                    
                 break;
                default:
                    break;
            }
        });
    
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//creación de menú principal

function obtenerdatosmed(id){
    //crear mensaje de bienvenida
    rest.get("/api/medico/"+id_select+"?token="+token,function(estado,respuesta){
        if (estado==200){
            var mensaje_bienvenida=document.getElementById("mensaje de bienvenida");
            mensaje_bienvenida.innerHTML="bienvenido "+respuesta.nombre;
        }
        });
    //coge los pacientes del médico
    rest.get("/api/medico/"+id_select+"/pacientes"+"?token="+token,function(estado1,newPac){
        lista=document.getElementById("pacientes");
        //lista es la lista de pacientes
        //primero eliminamos todos los pacientes, si habia antes
        while(lista.hasChildNodes()){
            lista.removeChild(lista.firstChild)};
        cont=0
        //se crean
        for (var i of newPac) {
            //se añaden <li> a la lista
            lista.innerHTML+="<li>"+"Paciente"+ " " + (cont+1) +":   " + i.id + " - " + i.nombre + " - " + '<button    onclick="verdatos('+i.id+')"> ver datos </button>' + "</li>";
            lista.innerHTML+='<button    onclick="duplicar('+i.id+')"> duplicar </button>'
            cont=cont+1;
                
            }
    })
}

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
function verdatos(id){
    //ver datos del paciente
    //coge las variables
    rest.get("/api/variable" +"?token="+token, (estado, respuesta6) => {
        if (estado!=500){
            console.log(respuesta6);
            variables_lista=respuesta6;
        }else{
            alert("error en base de datos")
        }

        });
    //cogemos todos los datos del paciente
    rest.get("/api/paciente/"+id+"?token="+token , (estado, respuesta) => {
        datos=respuesta;
        //comprueba si esta mal algo
        if (estado != 200) {
            alert("Error cargando el paciente");
            return;
        }
        //recojo la variable lsita
        var datos_pac= document.getElementById("lista");
        //la vacío
        datos_pac.innerHTML = "";
        //la relleno de los datos del paciente
        for (var i of datos) {
            datos_pac.innerHTML += "<li>" + i+ "</li>";
            }
        // le añado un botón de editar con el id del paciente
        datos_pac.innerHTML += '<button onclick="editar('+id+')">editar</button>' ;
        //las muestras    
        rest.get("/api/paciente/"+id+"/muestras"+"?token="+token , (estado, respuesta2) => {
            //recojo la variable de lista de muestras
            select_muestras=document.getElementById("muestras");
            //cuando cambia el filtro de varibales, se reincia verdatos
            document.getElementById("variables").setAttribute("onchange","verdatos("+id+")");
            select_muestras.innerHTML = "";
            // lista de muestas vaciada
            //se relaciona el nombre de la variable con el id de la variable
            variable=document.getElementById("variables").value;
            for (var i of variables_lista){

                if (variable==i.nombre){

                    variable=i.id
                }

            }

            //respuesta2 es las muestras del paciente seleccionada. y j.variable devuelve el idVariable de la muestra
            for (var j of respuesta2) {

                if (j.variable==variable){
                    select_muestras.innerHTML += "<li>valor: " + j.valor+ "fecha: "+j.fecha+"</li>";
                }    
            }
        });    
    });
    cambiarSeccion('datospaciente')

}
function duplicar(id){
    rest.post("/api/paciente/"+id+"/duplicar"+"?token="+token,function(estado,res){

        if (estado==201){
            entrar();            
        }
        else{
            alert("id ya existe");
        }
    });
}
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//funcion añadir

    function añadir(){
        //recojo datos del form
        var datos={id: document.getElementById("id_form").value,
        fecha_nacimiento:document.getElementById("fecha_naci_form").value ,
        codigo_acceso:document.getElementById("codac_form").value,
        observaciones: document.getElementById("observaciones_form").value,
        nombre:document.getElementById("nom_form").value,
        medico: document.getElementById("medico_form").value,
        genero:document.getElementById("genero_form").value,


        };
        rest.post("/api/medico/"+id_select+"/pacientes"+"?token="+token,datos,function(estado,resp){
            if (estado==201){

                entrar();            
            }
            else{
                alert("id ya existe");
            }
        });

    }
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
//
    function editar(id){
        //lo mismo que añadir
        var datos={id:id,
        fecha_nacimiento:document.getElementById("fecha_naciEd").value ,
        codigo_acceso:document.getElementById("codacEd").value,
        observaciones: document.getElementById("observacionesEd").value,
        nombre:document.getElementById("nomEd").value,
        medico: document.getElementById("medicoEd").value,
        genero:document.getElementById("generoEd").value,
    };
    rest.get("/api/paciente/"+id+"?token="+token , (estado, respuesta) => {
        datos_pac=respuesta;
        //comprueba que no esté vacía
        if ( datos.observaciones=="" & datos.genero=="" & datos.nombre=="" & datos.medico=="" & datos.fecha_nacimiento=="" & datos.codigo_acceso==""){
            alert("Error editando paciente");
        }
        else{
            if(datos.observaciones==""){
                datosobservaciones=datos_pac[5]
            }
            if(datos.genero==""){
                datos.genero=datos_pac[3]
            }
            if(datos.nombre==""){
                datos.nombre=datos_pac[1]
            }
            if(datos.medico==""){
                datos.medico=datos_pac[4]
            }

            if(datos.fecha_nacimiento==""){
                datos.fecha_nacimiento=datos_pac[2]
            }
        }
        
        
        //envía los datos
        rest.put("/api/paciente/"+id+"?token="+token , datos, (estado,respuesta) => {
            //si datos.id es diferente al id anterior te recarga la página
            if (estado == 201) { 
                if (datos.id!=id & datos.id!=""){
                    verdatos(datos.id); 
                }
                else{
                    verdatos(id)
                }                      
            }else{
                alert("Error introduciendo nuevo paciente");
                
            }
        });
    }); 

        };
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
function cambiar_Direct(){
    rest.put("/api/hospital/cambiar_director" , (estado,respuesta) => {
        //si datos.id es diferente al id anterior te recarga la página
        console.log(estado)
        if (estado == 201) { 
               alert("datos cambiados")
            }                      
        else{
            console.log(estado)
            alert("Error introduciendo nuevo paciente");
            
        }
    });

};



    
//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------

    function datosUsuario(){
        var usuario = document.getElementById("usuario").value;
        //...
    }

    function salir(){
        cambiarSeccion("inicio");
    }
    function volver(){
        cambiarSeccion("menu-principal")
    }