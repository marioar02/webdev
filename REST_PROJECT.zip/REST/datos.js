// BD
var medicos = [
    { id: 5, nombre: "Mario", login: "xxx" ,password: "secreto"},
    { id: 6, nombre: "Albert", login: "yyy" ,password: "lll"},
];
var pacientes = [
    { id: 1 , nombre:"javi" ,fecha_nacimiento:new Date('2018-10-15'),genero:"masc",medico: 5, codigo_acceso: "B" ,observaciones: ""},
    { id: 2 , nombre:"javi elda",fecha_nacimiento:new Date('2018-10-15'),genero:"masc",medico: 5, codigo_acceso: "A" ,observaciones: ""},
    { id: 3 , nombre:"Mario" ,fecha_nacimiento:new Date('2018-10-15'),genero:"masc",medico: 5, codigo_acceso: "C" ,observaciones: "se muere"},
    { id: 4 , nombre:"Mario Alicante" ,fecha_nacimiento:new Date('2018-10-15'),genero:"masc",medico: 6, codigo_acceso: "D" ,observaciones: "no se muere"}
];
var variables = [
    { id: 1, nombre: "peso"}, { id: 2, nombre: "altura"}, { id: 3, nombre: "IMC"}, { id: 4, nombre: "porcentaje de grasa"},
];
var muestras= [
    { id: 1, paciente: 1,variable: 1,fecha:new Date('2018-10-15'),valor: 50},
    { id: 2, paciente: 1,variable: 1,fecha:new Date('2018-10-16'),valor: 55},
    { id: 3, paciente: 1,variable: 2,fecha:new Date('2018-10-17'),valor: 50},
    { id: 5, paciente: 2,variable: 1,fecha:new Date('2018-10-18'),valor: 80},
    { id: 4, paciente: 2,variable: 1,fecha:new Date('2018-10-19'),valor: 80},
    { id: 6, paciente: 2,variable: 2,fecha:new Date('2018-10-20'),valor: 50},
    { id: 7, paciente: 1,variable: 3,fecha:new Date('2018-10-21'),valor: 50},
    { id: 8, paciente: 1,variable: 4,fecha:new Date('2018-10-22'),valor: 50},
    { id: 9, paciente: 2,variable: 3,fecha:new Date('2018-10-23'),valor: 50},
    { id: 10, paciente: 2,variable: 4,fecha:new Date('2018-10-24'),valor: 50},
    { id: 11, paciente: 3,variable: 1,fecha:new Date('2018-10-25'),valor: 50},
    { id: 12, paciente: 3,variable: 1,fecha:new Date('2018-10-26'),valor: 55},
    { id: 13, paciente: 4,variable: 2,fecha:new Date('2018-10-27'),valor: 50},
    { id: 14, paciente: 4,variable: 1,fecha:new Date('2018-10-28'),valor: 80},
    { id: 15, paciente: 4,variable: 1,fecha:new Date('2018-10-29'),valor: 80},
    { id: 16, paciente: 4,variable: 2,fecha:new Date('2018-10-30'),valor: 50},
    { id: 17, paciente: 3,variable: 3,fecha:new Date('2018-11-01'),valor: 50},
    { id: 18, paciente: 3,variable: 4,fecha:new Date('2018-11-02'),valor: 50},
    { id: 19, paciente: 4,variable: 3,fecha:new Date('2018-11-03'),valor: 50},
    { id: 20, paciente: 4,variable: 4,fecha:new Date('2018-11-04'),valor: 50},
];
//
module.exports.pacientes=pacientes;
module.exports.medicos=medicos;
module.exports.muestras=muestras;
module.exports.variables=variables;