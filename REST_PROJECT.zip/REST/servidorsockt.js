// Crear un servidor HTTP
var http = require("http");
var httpServer = http.createServer();
var datos=require("./datos.js")

// Crear servidor WS
var WebSocketServer = require("websocket").server; // instalar previamente: npm install websocket
var wsServer = new WebSocketServer({
	httpServer: httpServer
});
mensajes=[];
conexiones=[];
// Iniciar el servidor HTTP en un puerto
var puerto = 4444;
httpServer.listen(puerto, function () {
	console.log("Servidor de WebSocket iniciado en puerto:", puerto);
});
wsServer.on("request", function (request) { // este callback se ejecuta cuando llega una nueva conexión de un cliente
	var connection = request.accept("pacientes", request.origin); // aceptar conexión
	 // guardar la conexións
	//console.log("Cliente conectado. Ahora hay", conexiones.length);
	connection.sendUTF(JSON.stringify({operacion:"login",datos:datos.pacientes})); // enviar por primera vez la lista de pacientes
	//listaPacientes(connection); // enviar la lista de pacientes al nuevo cliente
	connection.on("message", function (message) { // mensaje recibido del cliente
		if (message.type === "utf8") {
			console.log("Mensaje recibido de cliente: " + message.utf8Data);
			var msg = JSON.parse(message.utf8Data);
			if(msg.operacion=="enviar_amigos"){
				for (var i of msg.ids){
					for (var j of conexiones){
						if (j.rol=="paciente"){
							if (j.id==i){
								j.sendUTF(JSON.stringify({operacion:"notificar",mensaje:msg.mensaje}));
								console.log("enviado_a_cliente")
							}
						}
					}
				};
			}
			if (msg.operacion=="identificar"){
					connection.rol=msg.rol;
					connection.id=msg.id;
					conexiones.push(connection);
			}
			if(msg.operacion=="todos"){
				console.log("todos")
					for (var j of conexiones){
						if (j.rol=="paciente"){
								if(j.id!=msg.id_sent){
									console.log(j.id,msg.id_sent)
									j.sendUTF(JSON.stringify({operacion:"notificar",mensaje:msg.mensaje}));
								}
							}
						}
					}
			if(msg.operacion=="medico"){
				console.log("medico")
				for (var i of msg.ids){
					for (var j of conexiones){
						if (j.rol=="medico"){
							if (j.id==i){
								j.sendUTF(JSON.stringify({operacion:"notificar",mensaje:msg.mensaje}));
								console.log("enviado_a_cliente")
							}
						}
					}
				};
			}
			console.log("Ahora los pacientes son:", pacientes);
		}
	});
	connection.on("close", function (reasonCode, description) { // conexión cerrada
		conexiones.splice(conexiones.indexOf(connection), 1);
		console.log("Cliente desconectado. Ahora hay", conexiones.length);
	});
});
